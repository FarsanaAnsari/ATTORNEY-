# Attorney Office Manager

A small Laravel starter project for a law office. It includes:

- Client management
- Case management
- Dashboard with summary cards
- Clean Blade templates

## Stack

- PHP 8.2+
- Laravel 11+
- Blade
- SQLite or MySQL

## Features

- Create, edit, list, and delete clients
- Create, edit, list, and delete legal cases
- Link each case to a client
- Track case status: open, pending, closed
- Dashboard with totals

## Quick start

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan serve
```

## Routes

- `/` → dashboard
- `/clients` → clients CRUD
- `/cases` → cases CRUD

## Notes

This repository is a compact starter scaffold intended for GitHub. It does not include authentication scaffolding or frontend build tooling so it stays small and easy to review.
