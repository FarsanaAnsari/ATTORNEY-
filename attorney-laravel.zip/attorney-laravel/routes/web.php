<?php

use App\Http\Controllers\CaseController;
use App\Http\Controllers\ClientController;
use App\Models\ClientCase;
use App\Models\Client;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('dashboard.index', [
        'clientCount' => Client::count(),
        'caseCount' => ClientCase::count(),
        'openCaseCount' => ClientCase::where('status', 'open')->count(),
        'closedCaseCount' => ClientCase::where('status', 'closed')->count(),
    ]);
})->name('dashboard');

Route::resource('clients', ClientController::class);
Route::resource('cases', CaseController::class);
