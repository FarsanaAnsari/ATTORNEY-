@extends('layouts.app')

@section('content')
<div class="card">
    <h1>{{ $case->title }}</h1>
    <p><strong>Case Number:</strong> {{ $case->case_number }}</p>
    <p><strong>Client:</strong> {{ $case->client->full_name }}</p>
    <p><strong>Practice Area:</strong> {{ $case->practice_area }}</p>
    <p><strong>Status:</strong> {{ ucfirst($case->status) }}</p>
    <p><strong>Hearing Date:</strong> {{ optional($case->hearing_date)->format('Y-m-d') }}</p>
    <p><strong>Notes:</strong><br>{{ $case->notes }}</p>
</div>
@endsection
