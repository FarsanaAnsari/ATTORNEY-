@csrf
<label>Client</label>
<select name="client_id" required>
    <option value="">Select a client</option>
    @foreach($clients as $clientOption)
        <option value="{{ $clientOption->id }}" @selected(old('client_id', $case->client_id ?? '') == $clientOption->id)>
            {{ $clientOption->full_name }}
        </option>
    @endforeach
</select>

<label>Title</label>
<input type="text" name="title" value="{{ old('title', $case->title ?? '') }}" required>

<label>Case Number</label>
<input type="text" name="case_number" value="{{ old('case_number', $case->case_number ?? '') }}" required>

<label>Practice Area</label>
<input type="text" name="practice_area" value="{{ old('practice_area', $case->practice_area ?? '') }}" required>

<label>Status</label>
<select name="status" required>
    @foreach(['open', 'pending', 'closed'] as $status)
        <option value="{{ $status }}" @selected(old('status', $case->status ?? 'open') === $status)>{{ ucfirst($status) }}</option>
    @endforeach
</select>

<label>Hearing Date</label>
<input type="date" name="hearing_date" value="{{ old('hearing_date', isset($case->hearing_date) ? $case->hearing_date->format('Y-m-d') : '') }}">

<label>Notes</label>
<textarea name="notes">{{ old('notes', $case->notes ?? '') }}</textarea>

<button type="submit">Save</button>
