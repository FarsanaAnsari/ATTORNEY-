@extends('layouts.app')

@section('content')
<div class="card">
    <h1>Edit Case</h1>
    <form method="POST" action="{{ route('cases.update', $case) }}">
        @csrf
        @method('PUT')
        @include('cases.form')
    </form>
</div>
@endsection
