@extends('layouts.app')

@section('content')
<div class="card">
    <h1>New Case</h1>
    <form method="POST" action="{{ route('cases.store') }}">
        @include('cases.form')
    </form>
</div>
@endsection
