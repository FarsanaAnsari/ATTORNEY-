@extends('layouts.app')

@section('content')
<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;">
        <h1>Cases</h1>
        <a class="btn" href="{{ route('cases.create') }}">Add Case</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Case #</th>
                <th>Title</th>
                <th>Client</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($cases as $case)
                <tr>
                    <td>{{ $case->case_number }}</td>
                    <td>{{ $case->title }}</td>
                    <td>{{ $case->client->full_name }}</td>
                    <td>{{ ucfirst($case->status) }}</td>
                    <td class="actions">
                        <a class="btn btn-secondary" href="{{ route('cases.show', $case) }}">View</a>
                        <a class="btn" href="{{ route('cases.edit', $case) }}">Edit</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
