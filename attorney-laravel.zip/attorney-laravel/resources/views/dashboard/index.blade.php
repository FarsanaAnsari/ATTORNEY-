@extends('layouts.app')

@section('content')
    <div class="card">
        <h1>Attorney Office Dashboard</h1>
        <p>Simple overview of clients and active legal matters.</p>
    </div>

    <div class="grid">
        <div class="card"><div>Total Clients</div><div class="stat">{{ $clientCount }}</div></div>
        <div class="card"><div>Total Cases</div><div class="stat">{{ $caseCount }}</div></div>
        <div class="card"><div>Open Cases</div><div class="stat">{{ $openCaseCount }}</div></div>
        <div class="card"><div>Closed Cases</div><div class="stat">{{ $closedCaseCount }}</div></div>
    </div>
@endsection
