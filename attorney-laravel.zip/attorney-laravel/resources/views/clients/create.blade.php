@extends('layouts.app')

@section('content')
<div class="card">
    <h1>New Client</h1>
    <form method="POST" action="{{ route('clients.store') }}">
        @include('clients.form')
    </form>
</div>
@endsection
