@extends('layouts.app')

@section('content')
<div class="card">
    <h1>Edit Client</h1>
    <form method="POST" action="{{ route('clients.update', $client) }}">
        @csrf
        @method('PUT')
        @include('clients.form')
    </form>
</div>
@endsection
