@extends('layouts.app')

@section('content')
<div class="card">
    <h1>{{ $client->full_name }}</h1>
    <p><strong>Email:</strong> {{ $client->email }}</p>
    <p><strong>Phone:</strong> {{ $client->phone }}</p>
    <p><strong>Address:</strong> {{ $client->address }}</p>
</div>

<div class="card">
    <h2>Cases</h2>
    <ul>
        @forelse($client->cases as $case)
            <li>{{ $case->title }} ({{ $case->status }})</li>
        @empty
            <li>No cases yet.</li>
        @endforelse
    </ul>
</div>
@endsection
