@csrf
<label>First Name</label>
<input type="text" name="first_name" value="{{ old('first_name', $client->first_name ?? '') }}" required>

<label>Last Name</label>
<input type="text" name="last_name" value="{{ old('last_name', $client->last_name ?? '') }}" required>

<label>Email</label>
<input type="email" name="email" value="{{ old('email', $client->email ?? '') }}">

<label>Phone</label>
<input type="text" name="phone" value="{{ old('phone', $client->phone ?? '') }}">

<label>Address</label>
<textarea name="address">{{ old('address', $client->address ?? '') }}</textarea>

<button type="submit">Save</button>
