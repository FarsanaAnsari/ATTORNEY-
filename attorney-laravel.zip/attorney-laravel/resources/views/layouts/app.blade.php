<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attorney Office Manager</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f5f7fb; color: #222; }
        nav { background: #1f3c88; padding: 14px 24px; }
        nav a { color: white; text-decoration: none; margin-right: 18px; font-weight: 600; }
        .container { max-width: 1100px; margin: 30px auto; padding: 0 16px; }
        .card { background: white; border-radius: 10px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
        .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
        .stat { font-size: 28px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; border-bottom: 1px solid #e6e6e6; text-align: left; }
        input, select, textarea { width: 100%; padding: 10px; margin-top: 6px; margin-bottom: 14px; border: 1px solid #ccc; border-radius: 6px; }
        button, .btn { background: #1f3c88; color: white; border: none; padding: 10px 14px; border-radius: 6px; text-decoration: none; display: inline-block; cursor: pointer; }
        .btn-secondary { background: #6b7280; }
        .actions { display: flex; gap: 8px; }
        .success { background: #e8fff0; color: #166534; padding: 12px; border-radius: 8px; margin-bottom: 14px; }
        @media (max-width: 800px) { .grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>
    <nav>
        <a href="{{ route('dashboard') }}">Dashboard</a>
        <a href="{{ route('clients.index') }}">Clients</a>
        <a href="{{ route('cases.index') }}">Cases</a>
    </nav>

    <div class="container">
        @if(session('success'))
            <div class="success">{{ session('success') }}</div>
        @endif

        @yield('content')
    </div>
</body>
</html>
