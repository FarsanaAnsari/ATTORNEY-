<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\ClientCase;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CaseController extends Controller
{
    public function index(): View
    {
        $cases = ClientCase::with('client')->latest()->paginate(10);
        return view('cases.index', compact('cases'));
    }

    public function create(): View
    {
        $clients = Client::orderBy('first_name')->get();
        return view('cases.create', compact('clients'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'client_id' => ['required', 'exists:clients,id'],
            'title' => ['required', 'string', 'max:255'],
            'case_number' => ['required', 'string', 'max:100', 'unique:cases,case_number'],
            'practice_area' => ['required', 'string', 'max:100'],
            'status' => ['required', 'in:open,pending,closed'],
            'hearing_date' => ['nullable', 'date'],
            'notes' => ['nullable', 'string'],
        ]);

        ClientCase::create($validated);

        return redirect()->route('cases.index')->with('success', 'Case created successfully.');
    }

    public function show(ClientCase $case): View
    {
        $case->load('client');
        return view('cases.show', compact('case'));
    }

    public function edit(ClientCase $case): View
    {
        $clients = Client::orderBy('first_name')->get();
        return view('cases.edit', compact('case', 'clients'));
    }

    public function update(Request $request, ClientCase $case): RedirectResponse
    {
        $validated = $request->validate([
            'client_id' => ['required', 'exists:clients,id'],
            'title' => ['required', 'string', 'max:255'],
            'case_number' => ['required', 'string', 'max:100', 'unique:cases,case_number,' . $case->id],
            'practice_area' => ['required', 'string', 'max:100'],
            'status' => ['required', 'in:open,pending,closed'],
            'hearing_date' => ['nullable', 'date'],
            'notes' => ['nullable', 'string'],
        ]);

        $case->update($validated);

        return redirect()->route('cases.index')->with('success', 'Case updated successfully.');
    }

    public function destroy(ClientCase $case): RedirectResponse
    {
        $case->delete();
        return redirect()->route('cases.index')->with('success', 'Case deleted successfully.');
    }
}
